import React from "react";
import { Messages } from "./Messages";
export const Chat = () => {
  return (
    <div className="chat">
      {/* <div className="chatInfor"></div> */}
      <Messages />
    </div>
  );
};
